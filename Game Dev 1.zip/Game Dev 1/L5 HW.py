import random

# Initialize empty lists to store marks
marks_less_equal_30 = []
marks_between_31_69 = []
marks_greater_equal_70 = []

# Generate random marks for 20 students
for _ in range(20):
    mark = random.randint(0, 100)  # Generate random marks between 0 and 100
    if mark <= 30:
        marks_less_equal_30.append(mark)
    elif mark >= 70:
        marks_greater_equal_70.append(mark)
    else:
        marks_between_31_69.append(mark)

# Display the output lists
print("Marks less than or equal to 30:", marks_less_equal_30)
print("Marks between 31 and 69:", marks_between_31_69)
print("Marks greater than or equal to 70:", marks_greater_equal_70)