# Create the first set
print("Enter elements for the first set (separated by spaces):")
elements1 = input().split()
set1 = set(elements1)

# Create the second set
print("Enter elements for the second set (separated by spaces):")
elements2 = input().split()
set2 = set(elements2)

while True:
    # Display the menu and get the user's choice
    print("\nSet Operations Menu:")
    print("1. Union")
    print("2. Intersection")
    print("3. Difference")
    print("4. Symmetric Difference")
    choice = input("Enter your choice (1-4): ")

    # Perform the selected set operation
    if choice == '1':
        result = set1.union(set2)
        operation = "Union"
    elif choice == '2':
        result = set1.intersection(set2)
        operation = "Intersection"
    elif choice == '3':
        result = set1.difference(set2)
        operation = "Difference"
    elif choice == '4':
        result = set1.symmetric_difference(set2)
        operation = "Symmetric Difference"
    else:
        print("Invalid choice. Please try again.")
        continue

    # Display the result of the set operation
    print(f"\nThe {operation} of the sets is: {result}")

    # Ask if the user wants to perform another operation
    again = input("\nDo you want to perform another operation? (yes/no): ").lower()
    if again != 'yes':
        break