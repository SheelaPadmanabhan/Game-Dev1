game_dict = {
    "football": "A popular team sport played with a spherical ball between two teams of eleven players.",
    "basketball": "A team sport in which two teams, most commonly of five players each, compete to score points by throwing a ball through the opponent's hoop.",
    "cricket": "A bat-and-ball game played between two teams of eleven players on a field at the center of which is a 22-yard pitch with a wicket at each end.",
}
print(game_dict["football"])
print(game_dict)

#insert a item to dict
game_dict["Roblox"]="Its a 3D game created using Roblox Studio"

# Accessing values
print(game_dict["basketball"])  
print(game_dict["cricket"])   

# Removing key-value pairs
del game_dict["cricket"]
print(game_dict)

# Iterating over keys
for key in game_dict:
    print(key)

# Iterating over values
for value in game_dict.values():
    print(value)

# Iterating over key-value pairs
for key, value in game_dict.items():
    print(key, value)

