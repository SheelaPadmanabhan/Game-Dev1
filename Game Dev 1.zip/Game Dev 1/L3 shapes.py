import pgzrun



def draw():
    screen.clear()
    screen.fill("blue")
    screen.draw.text("Python Zero is Installed",(300,100),color="red")
    # rect = Rect((100, 100), (100, 300))
    # rect.center = 150, 150
    screen.draw.rect(rect, "RED")
    screen.draw.filled_circle((250,350),70,color="green")

pgzrun.go()