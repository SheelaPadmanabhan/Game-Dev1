# Initialize an empty list to store names
names = []

while True:
  # Display the menu
  print("\nMenu:")
  print("1. Add a name to the list")
  print("2. Change a name in the list")
  print("3. Delete a name from the list")
  print("4. View all names in the list")
  print("5. End the program")

  # Prompt the user to make a choice
  choice = input("Enter your choice (1-5): ")

  if choice == '1':
      # Add a name to the list
      new_name = input("Enter the name to add: ")
      names.append(new_name)
      print(f"{new_name} has been added to the list.")
  elif choice == '2':
      # Change a name in the list
      old_name = input("Enter the name you want to change: ")
      if old_name in names:
          new_name = input("Enter the new name: ")
          index = names.index(old_name)
          names[index] = new_name
          print(f"{old_name} has been changed to {new_name}.")
      else:
          print(f"{old_name} is not in the list.")
  elif choice == '3':
      # Delete a name from the list
      name_to_delete = input("Enter the name you want to delete: ")
      if name_to_delete in names:
          names.remove(name_to_delete)
          print(f"{name_to_delete} has been removed from the list.")
      else:
          print(f"{name_to_delete} is not in the list.")
  elif choice == '4':
      # View all names in the list
      if names:
          print("Names in the list:")
          for name in names:
              print(name)
      else:
          print("The list is empty.")
  elif choice == '5':
      # End the program
      print("Ending the program. Goodbye!")
      break
  else:
      # Invalid choice
      print("Invalid choice. Please try again.")