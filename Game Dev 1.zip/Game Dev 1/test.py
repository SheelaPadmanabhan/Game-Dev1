import pgzrun
import random
import time

WIDTH = 500
HEIGHT=600

bee = Actor("img")
flower = Actor("img1")
# bee.pos=100,100
bee.x=100
bee.y=100


score=0
gameover=False
def draw():
    screen.blit("bg",(0,0))
    flower.draw()
    bee.draw()
    # screen.draw.text(msg,(300,100))
    screen.draw.text(f"Score: {score}",(100,50))
    if gameover:
        screen.fill("Purple")
        screen.draw.text("Game Over",(250,200))
        screen.draw.text(f"Your Final Score is: {score}",(250,250))
def update():
    global score
    if keyboard.up:
        bee.y-=2
    if keyboard.down:
        bee.y+=2
    if keyboard.left:
        bee.x-=2
    if keyboard.right:
        bee.x+=2
    if bee.colliderect(flower):
        flower.x =random.randint(50,WIDTH-50)
        flower.y =random.randint(50,HEIGHT-50)
        score+=1
def exit():
    global gameover
    gameover=True
clock.schedule(exit,20)
pgzrun.go()