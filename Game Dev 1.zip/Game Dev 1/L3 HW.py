import pgzrun
WIDTH=500
HEIGHT=500
def draw():
    screen.fill("pink")
    # screen.draw.filled_circle((300,300),50,"red")
    # screen.draw.line((100,400),(300,300),"orange")
    rect=Rect((100,100),(50,200))
    rect.center=200,200
    screen.draw.rect(rect,"blue")
    



    # screen.clear()
    # screen.fill("cyan")
    # screen.draw.line((0,100),(1000,100),"red")
    # screen.draw.filled_circle((200,200),100,"yellow")
    # rect=Rect((100,400),(100,50))
    # rect.center=120,120
    # screen.draw.rect(rect,"green")
   


pgzrun.go()