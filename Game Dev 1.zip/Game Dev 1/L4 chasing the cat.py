import pgzrun
import random
import time

WIDTH = 500
HEIGHT=600

alien = Actor("alienn")
cat = Actor("cat")
# alien.pos=100,100
alien.x=100
alien.y=100


score=0
gameover=False
def draw():
    screen.blit("bg",(0,0))
    cat.draw()
    alien.draw()
    # screen.draw.text(msg,(300,100))
    screen.draw.text(f"Score: {score}",(100,50))
    if gameover:
        screen.fill("red")
        screen.draw.text("Game Over",(250,200))
        screen.draw.text(f"Score: {score}",(250,250))
def update():
    global score
    if keyboard.up:
        alien.y-=2
    if keyboard.down:
        alien.y+=2
    if keyboard.left:
        alien.x-=2
    if keyboard.right:
        alien.x+=2
    if alien.colliderect(cat):
        cat.x =random.randint(50,WIDTH-50)
        cat.y =random.randint(50,HEIGHT-50)
        score+=1
def exit():
    global gameover
    gameover=True
clock.schedule(exit,20)
pgzrun.go()