# List to store records of all groups
group_records = []

# Number of groups
num_groups = 5

for i in range(num_groups):
    print(f"\nEnter details for group {i + 1}:")
    
    # Prompt the user to enter the details for each group
    groupname = input("Enter the group name: ")
    Sizeofthegroup = input("Enter the size of the group: ")
    dateofthecompetition = input("Enter the date of the competition (YYYY-MM-DD): ")
    venue = input("Enter the venue of the competition: ")
    typeofthemedal = input("Enter the type of the medal (gold/silver/bronze): ")

    # Create a tuple with the entered details
    group_record = (groupname, Sizeofthegroup, dateofthecompetition, venue, typeofthemedal)
    
    # Add the tuple to the list of group records
    group_records.append(group_record)

# Display the recorded details
print("\nRecorded details of all groups:")
for record in group_records:
    print(record)

