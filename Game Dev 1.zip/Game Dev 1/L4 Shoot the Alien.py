import pgzrun
import random

WIDTH = 800
HEIGHT = 600

alien = Actor("alien.png")
alien.pos = (random.randint(50, WIDTH - 50), random.randint(50, HEIGHT - 50))

def draw():
    screen.fill((0, 0, 0))
    alien.draw()

def update():
    pass

def on_mouse_down(pos):
    global alien
    if alien.collidepoint(pos):
        print("You shot the alien!")
        alien = Actor("alien")
        alien.pos = (random.randint(50, WIDTH - 50), random.randint(50, HEIGHT - 50))


pgzrun.go()