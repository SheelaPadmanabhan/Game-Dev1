import pgzrun
from random import randint
import time
WIDTH = 600
HEIGHT=500
alien = Actor("alien")
alien.pos=300,300
msg="Shoot the Alien"
score=0
def draw():
    screen.fill("purple")
    alien.draw()
    screen.draw.text(msg,(200,50))
    screen.draw.text(f"Score: {score}",(100,50))

def on_mouse_down(pos):
    global msg,score
    #print(alien.collidepoint(pos))
    if alien.collidepoint(pos):
        alien.x=randint(50,550)
        alien.y=randint(50,HEIGHT-50)
        # time.sleep(1)
        msg="Good Shot"
        score +=1
    else: 
        msg="You Missed"
        score -=1
        
pgzrun.go()