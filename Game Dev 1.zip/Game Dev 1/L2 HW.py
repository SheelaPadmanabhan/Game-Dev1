# Dictionary containing student names and their total marks
student_register = {
    "Alice": 385,
    "Bob": 390,
    "Charlie": 478,
    "David": 492,
    "Eve": 488,
    "Frank": 275,
    "Grace": 395,
    "Hannah": 480,
    "Ivy": 385,
    "Jack": 489
}

# Prompt the user to enter a student's name
student_name = input("Enter the student's name: ")

# Check if the student's name is in the dictionary
if student_name in student_register:
    # Output the total marks of the student
    print(f"{student_name}'s total marks are: {student_register[student_name]}")
else:
    # Inform the user that the student's name is not in the register
    print("Student not found in the register.")