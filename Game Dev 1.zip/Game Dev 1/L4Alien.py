import pgzrun
from random import randint
#pygame standard for deciding the title of your game window
TITLE="Good shot"
#pygame standard for deciding the width and height ypur game window
WIDTH=500
HEIGHT=500
#There’s a built-in class called Actor that you can use to represent a graphic to be drawn to the screen.
alien = Actor('alien')
alien.pos = 100, 56
WIDTH = 500
HEIGHT = alien.height + 150
alien.topright=(0,10)
#screen is a built-in that represents the window display. 
#It has a range of methods for drawing sprites and shapes. 
#The screen.fill() method call is filling the screen with a solid colour,
#specified as a (red, green, blue)
def draw():
    screen.clear()
    screen.fill((128, 0, 0))
    alien.draw()
    #Your alien should now be appearing on screen! By passing the string 'alien' to the Actor class,
    #  it automatically loads the sprite, and has attributes like positioning and dimensions. 
    # This allows us to set the HEIGHT of the window based on the height of the alien.
    # The alien.draw() method draws the sprite to the screen at its current position.
    #Let’s set the alien off-screen; change the alien.pos
    #Note how you can assign to topright to move the alien actor by its top-right corner. 
    # If the right-hand edge of the alien is at 0, the the alien is just offscreen to the left. 
    # Now let’s make it move. 
def update():
    alien.left+=10
    if alien.left>WIDTH:
        alien.right=0
def on_mouse_down(pos):
    if alien.collidepoint(pos):
        sounds.eep.play()
        print("Eek!")
    else:
        print("You missed me")
pgzrun.go()
