# create a tuple
numbers = (1, 2, -5)
print(numbers)
# Output: (1, 2, -5)





# Access Items Using Index
languages = ('Python', 'Swift', 'C++')
# access the first item
print(languages[0])   # Python
# access the third item
print(languages[2])   # C++




# Tuple Cannot be Modified
cars = ('BMW', 'Tesla', 'Ford', 'Toyota')
# trying to modify a tuple
cars[0] = 'Nissan'    # error  
print(cars)



# len() function to find the number of items
cars = ('BMW', 'Tesla', 'Ford', 'Toyota')
print('Total Items:', len(cars)) 
# Output: Total Items: 4



# Iterate Through a Tuple
fruits = ('apple','banana','orange')
# iterate through the tuple
for fruit in fruits:
    print(fruit)




# Check if an Item Exists in the Tuple
colors = ('red', 'orange', 'blue')
print('yellow' in colors)    # False
print('red' in colors)       # True




# delete the tuple itself using the del statement
animals = ('dog', 'cat', 'rat')
# deleting the tuple
del animals



# Example tuple
example_tuple = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9)

# Slicing examples
# Get elements from index 2 to 5 (exclusive)
slice_1 = example_tuple[2:5]
print("Slice 1 (2:5):", slice_1)  # Output: (2, 3, 4)
# Get elements from the beginning to index 4 (exclusive)
slice_2 = example_tuple[:4]
print("Slice 2 (:4):", slice_2)  # Output: (0, 1, 2, 3)
# Get elements from index 5 to the end
slice_3 = example_tuple[5:]
print("Slice 3 (5:):", slice_3)  # Output: (5, 6, 7, 8, 9)
# Get all elements with a step of 2
slice_4 = example_tuple[::2]
print("Slice 4 (::2):", slice_4)  # Output: (0, 2, 4, 6, 8)
# Get elements from index 1 to 7 with a step of 2
slice_5 = example_tuple[1:8:2]
print("Slice 5 (1:8:2):", slice_5)  # Output: (1, 3, 5, 7)
# Get all elements in reverse order
slice_6 = example_tuple[::-1]
print("Slice 6 (::-1):", slice_6)  # Output: (9, 8, 7, 6, 5, 4, 3, 2, 1, 0)




# Create a Python Tuple With One Item
# var = ('Hello')
# print(var)  # string

var = ('Hello',) 
print(var)  # tuple
# Output: ('Hello',)




# The count() method returns the number of times the specified element appears in the tuple.
# tuple of vowels
vowels = ('a', 'e', 'i', 'o', 'i', 'u')
# counts the number of i's in the tuple
count = vowels.count('i')
print(count) 
# Output: 2






# Packing and Unpacking in a tuple
# Packing values into a tuple
packed_tuple = 1, 2, 3, 4, 5
print(packed_tuple)
# Output: (1, 2, 3, 4, 5)

# Packing values with explicit parentheses
another_tuple = (10, 20, 30)
print(another_tuple)
# Output: (10, 20, 30)


# Unpacking a tuple into variables
packed_tuple = (1, 2, 3, 4, 5)

a, b, c, d, e = packed_tuple

print(a)  # Output: 1
print(b)  # Output: 2
print(c)  # Output: 3
print(d)  # Output: 4
print(e)  # Output: 5